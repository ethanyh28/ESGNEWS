﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace EsgNewsSearch
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //讀取INI檔,檔案文字編碼必須使用 utf8 without BOM_Notepad++ 才可讀取字詞
            string dirstr = Application.StartupPath + "\\EsgNewsSearch_utf8.ini";

            //get server path
            string SERVER_PATH = ExtensionMethods.MyExtensions.ReadString("VERSION_CONTROL", "SERVER", "", dirstr);
            //取得main program name
            string program_nm = ExtensionMethods.MyExtensions.ReadString("VERSION_CONTROL", "PROGRAM_NM", "", SERVER_PATH + "\\VERSION.INI");

            //取得update檔案最後異動時間
            var fi1 = new FileInfo(Application.StartupPath + "\\EsgUpdate.exe");
            var fi2 = new FileInfo(SERVER_PATH + "\\EsgUpdate.exe");

            if (fi1.LastWriteTime < fi2.LastWriteTime)
            {
                if (File.Exists(SERVER_PATH + "\\EsgUpdate.exe"))
                {
                    File.Delete(Application.StartupPath + "\\EsgUpdate.exe");
                    File.Copy(SERVER_PATH + "\\EsgUpdate.exe", Application.StartupPath + "\\EsgUpdate.exe");
                }
            }
            Application.Run(new F_EsgNewsSearch());
        }
    }
}
