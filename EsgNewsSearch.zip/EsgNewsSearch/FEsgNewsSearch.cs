﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using HtmlAgilityPack;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;
using System.Reflection;
using System.Runtime.InteropServices;


//using Google.APPI.Search;

namespace EsgNewsSearch
{


    public partial class F_EsgNewsSearch : Form
    {
        //loading 簡繁體中文轉換
        [DllImport("kernel32", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int LCMapString(int Locale, int dwMapFlags, string lpSrcStr, int cchSrc, [Out] string lpDestStr, int cchDest);

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        //讀取INI檔
        string dirstr = Application.StartupPath + "\\EsgNewsSearch.ini";

        // 透過OS層的元件進行轉換的動作 
        public static string ConvertChinese(string strSource, CharsetType enumCharsetType)
        {
            String strTarget = new String(' ', strSource.Length);
            int tReturn = LCMapString((int)CharsetType.Default, (int)enumCharsetType, strSource, strSource.Length, strTarget, strSource.Length);
            return strTarget;
        }

        // 轉換的語系型別
        public enum CharsetType
        {
            Default = 0x0800,
            Simplified = 0x02000000,
            Traditional = 0x04000000,
        }

        private WebClient webClient = new WebClient();

        public string UpdateDate = "";

        //ESG檢查負面關鍵字
        private string negative = ""; 

        //public DataTable dt = new DataTable();
        public string url = "";

        //Define Class to return news data
        public class ItemNews
        {
            public string searchword { get; set; }
            public string title { get; set; }
            public string link { get; set; }
            public string item_id { get; set; }
            public string PubDate { get; set; }
            public string Description { get; set; }
            public string Source { get; set; }
        }

        //建立資料源
        DataSet dsESG ;

        //建立資料表
        //System.Data.DataTable dtGoogleNews = new System.Data.DataTable("ns_news");
        System.Data.DataTable dtGoogleNews ;

        //主程式
        public F_EsgNewsSearch()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 2; //地區別 //預設台灣
            comboBox2.SelectedIndex = 2; //時間 //傳送新聞期間預設30天
            comboBox3.SelectedIndex = 1; //時間 //預設包含字詞
            toolStripStatusLabel1.Text = "使用者：" + Environment.UserName;
            toolStripStatusLabel3.Text = "使用者：" + Environment.UserName;
            timer1.Enabled = true;            
            tabControl1.SelectedIndex = 0; //初始值
            Build_DataSet(); //build a dataset

            //讀取負面關鍵字預設值
            StringBuilder data = new StringBuilder(255);

            //BAD WORD
            GetPrivateProfileString("ESG_NG_WORD", "negative", "", data, 255, dirstr);
            if (negative.Length == 0)
            { negative = data.ToString();  }
            else
            { negative = negative + "," + data.ToString();  }
            
            //Governance
            GetPrivateProfileString("ESG_NG_WORD", "governance", "", data, 255, dirstr);
            if (negative.Length == 0)
            { negative = data.ToString(); }
            else
            { negative = negative + "," + data.ToString(); }

            //Environmental
            GetPrivateProfileString("ESG_NG_WORD", "Environmental", "", data, 255, dirstr);
            if (negative.Length == 0)
            { negative = data.ToString(); }
            else
            { negative = negative + "," + data.ToString(); }

            //social
            GetPrivateProfileString("ESG_NG_WORD", "social", "", data, 255, dirstr);
            if (negative.Length == 0)
            { negative = data.ToString(); }
            else
            { negative = negative + "," + data.ToString(); }

            //檢查最後一字是 "," 移除它
            if (negative.LastIndexOf(",") != -1)
            {
                negative = negative.Substring(0, negative.Length - 1);
            }
        }

        //寫入TextBox
        private void write2text(string str)
        {
            textBox2.AppendText(str + System.Environment.NewLine);
        }

        //Googlenews_search1使用 news.google.com
        private void Googlenews_Search(string NewsParameters, int keyoption, string period, string lang)
        {
            try
            {
                //傳送網址
                string url = "";
                string RealSearchWord = "";
                System.Data.DataTable dt = new System.Data.DataTable();

                //傳送關鍵字-0.包含;1.完整
                switch (keyoption)
                {
                    case 0:
                        RealSearchWord = NewsParameters;
                        break;
                    case 1:
                        RealSearchWord = "\"" + NewsParameters + "\"";
                        break;
                }

                //設定時間變數
                string Newperiod = "";
                if (period == "過去24小時")
                { Newperiod = " when:1d"; }
                else if (period == "過去7天")
                { Newperiod = " when:7d"; }
                else if (period == "過去30天")
                { Newperiod = " when:30d"; }
                else if (period == "過去90天")
                { Newperiod = " when:90d"; }
                else if (period == "過去1年")
                { Newperiod = " when:1y"; }
                else if (period == "不限時間")
                { Newperiod = ""; }

                //選擇查詢國家
                if (lang == "中國-中文")
                {
                    url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-CN&gl=CN&ceid=CN:zh-Hans";
                }
                else if (lang == "香港-中文")
                {
                    url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-HK&gl=HK&ceid=HK:zh-Hant";
                }
                else if (lang == "美國-英文")
                {
                    url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=en-US&gl=US&ceid=US:en";
                }
                else if (lang == "日本-日文")
                {
                    url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=ja&gl=JP&ceid=JP:ja";
                }
                else //台灣-中文
                {
                    //網址轉碼
                    //url = Uri.EscapeUriString(url);
                    url = "https://news.google.com/rss/search?q=" + RealSearchWord + Newperiod + "&hl=zh-TW&gl=TW&ceid=TW:zh-Hant";
                }

                tb_url.Text = url;

                List<ItemNews> Detail = new List<ItemNews>();

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

                request.UserAgent = "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36";
                request.Accept = "text/html, application/xhtml+xml, */*";
                request.Method = "GET";

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Stream receiveStream = response.GetResponseStream();
                    StreamReader readStream = null;

                    if (response.CharacterSet == "")
                    {
                        readStream = new StreamReader(receiveStream);
                    }
                    else
                    {
                        readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));
                    }

                    //get news data in json string
                    string data = readStream.ReadToEnd();

                    //Declare Dataset for putting data in it.
                    DataSet ds = new DataSet();
                    StringReader reader = new StringReader(data);
                    ds.ReadXml(reader);
                    System.Data.DataTable dtGetNews = new System.Data.DataTable();

                    //drNews建立資料集Row
                    DataRow drNews;

                    int cnt = 1;
                    if (ds.Tables.Count > 3)
                    {
                        dtGetNews = ds.Tables["item"];

                        //開始查詢第一個公司
                        write2text("=="+ comboBox3.Text +"== " + NewsParameters + " =====");
                        //寫入XML離線資料
                        foreach (DataRow dtRow in dtGetNews.Rows)
                        {
                            //寫入google news 回訊
                            ItemNews DataObj = new ItemNews();
                            DataObj.searchword = NewsParameters;
                            DataObj.title = dtRow["title"].ToString();
                            DataObj.link = dtRow["link"].ToString();
                            DataObj.item_id = dtRow["item_id"].ToString();
                            DataObj.PubDate = dtRow["pubDate"].ToString();
                            DataObj.Description = dtRow["description"].ToString();
                            DataObj.Source = DataObj.title.Substring(DataObj.title.LastIndexOf(" - ") + 3);
                            Detail.Add(DataObj);
                            write2text(cnt.ToString() + ": " + "[" + DataObj.searchword + "]--" + DataObj.PubDate + "," + DataObj.Source + "," + DataObj.title);

                            //寫入 dataset 
                            DateTime oDate = Convert.ToDateTime(DataObj.PubDate);
                            drNews = dtGoogleNews.NewRow();
                            drNews["search_nm_"] = DataObj.searchword;
                            drNews["title_"] = DataObj.title;
                            drNews["link_"] = DataObj.link;
                            drNews["pub_date_"] = oDate.Year.ToString("0000") + oDate.Month.ToString("00") + oDate.Day.ToString("00");
                            drNews["desc_"] = DataObj.Description;
                            drNews["media_"] = DataObj.Source;
                            drNews["weight_"] = 0 ;
                            dtGoogleNews.Rows.Add(drNews);

                            cnt++;
                        }
                        dataGridView1.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;
                        dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;                        
                    }
                }
            }
            catch(Exception e)
            {
                MessageBox.Show(e.ToString());
            }
        }

        //匯出Excel
        private static void ExportExcel(string filename, DataGridView dgv)
        {
            string hyperlink = "";
            Microsoft.Office.Interop.Excel.Range tempRange;
            //有資料才匯出
            if (dgv.Rows.Count > 0)
            {
                string saveFileName = "";

                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.DefaultExt = "xlsx";
                saveDialog.Filter = "Excel檔案|*.xls;*.xlsx";
                saveDialog.FileName = filename;
                saveDialog.ShowDialog();
                saveFileName = saveDialog.FileName;

                if (saveFileName.IndexOf(":") < 0) return; //取消存檔

                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                if (xlApp == null)
                {
                    MessageBox.Show("無法建立Excel物件,可能未安裝Excel!");
                    return;
                }

                Microsoft.Office.Interop.Excel.Workbooks workbooks = xlApp.Workbooks;
                Microsoft.Office.Interop.Excel.Workbook workbook = workbooks.Add(Microsoft.Office.Interop.Excel.XlWBATemplate.xlWBATWorksheet);
                Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Worksheets[1]; //取得sheet1

                //寫入列印日期
                worksheet.Cells[1, 1] = "列印日期:";
                worksheet.Cells[1, 2] = "=NOW()";
                worksheet.Cells[1, 2].Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft; //置左
                //寫入標題
                for (int i = 0; i < dgv.ColumnCount ; i++)
                {
                    //排除寫入欄位
                    if (dgv.Columns[i].HeaderText != "大綱")
                    {
                        worksheet.Cells[1+1, i + 1] = dgv.Columns[i].HeaderText;
                        tempRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1 + 1, i + 1];
                        tempRange.Interior.Color = Color.LightGray ; //儲存格底色淡灰
                    }
                }
                //寫入數值
                for (int r = 0; r < dgv.Rows.Count; r++)
                {
                    for (int i = 0; i < dgv.ColumnCount ; i++)
                    {
                        //排除寫入欄位
                        if (dgv.Columns[i].HeaderText != "大綱" )
                        {
                            worksheet.Cells[r + 3, i + 1] = dgv.Rows[r].Cells[i].Value;
                        }

                        //增加Hyperlink設定
                        if (dgv.Columns[i].HeaderText == "原始連結")
                        {
                            hyperlink = dgv.Rows[r].Cells[i].Value.ToString() ;
                            //Microsoft.Office.Interop.Excel.Range tempRange = worksheet.get_Range("E"+ (r+2).ToString(),Type.Missing); //使用英文加位置
                            //Microsoft.Office.Interop.Excel.Range tempRange = worksheet.get_Range(worksheet.Cells[r + 2, i + 1], worksheet.Cells[r + 2, i + 1]); //一個範圍
                            tempRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[r + 3, i + 1]; //一個儲存格
                            worksheet.Hyperlinks.Add(tempRange, hyperlink, Type.Missing, Type.Missing, Type.Missing); //加掛超連結
                        }
                    }
                    System.Windows.Forms.Application.DoEvents();
                }
                //欄位長度自動調整
                worksheet.Columns.EntireColumn.AutoFit();

                if (saveFileName != "")
                {
                    try
                    {                        
                        workbook.SaveAs(saveFileName, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Missing.Value, Missing.Value, false, false, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlNoChange, Microsoft.Office.Interop.Excel.XlSaveConflictResolution.xlUserResolution, true, Missing.Value, Missing.Value, Missing.Value);
                        workbook.Saved = true;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("匯出檔時錯誤,檔案可能正被開啟!\n" + ex.Message);
                    }
                }

                xlApp.Quit();
                GC.Collect();//強行釋放
                MessageBox.Show(filename + "儲存成功", "提示", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("報表為空,無表格可匯出", "提示", MessageBoxButtons.OK);
            }
        }

        //建立暫存資料源
        private void Build_DataSet()
        {
            //建立資料源
            dsESG = new DataSet("NewsDB");

            //將Datatable加入資料源,以上取代此行
            //System.Data.DataTable dtGoogleNews = dsESG.Tables.Add("ns_news");
            dtGoogleNews = dsESG.Tables.Add("ns_news");

            //建立欄位
            //--查詢標的代碼 search_id_
            //dtGoogleNews.Columns.Add("search_id_", typeof(string));
            //--查詢標的名稱 search_nm_
            dtGoogleNews.Columns.Add("search_nm_", typeof(string));
            dtGoogleNews.Columns["search_nm_"].Caption = "關鍵字";
            //--發布日期 pub_date_
            dtGoogleNews.Columns.Add("pub_date_", typeof(string));
            dtGoogleNews.Columns["pub_date_"].Caption = "發布時間";
            //--來源媒體 media_
            dtGoogleNews.Columns.Add("media_", typeof(string));
            dtGoogleNews.Columns["media_"].Caption = "新聞來源";
            //--新聞標題 title_
            dtGoogleNews.Columns.Add("title_", typeof(string));
            dtGoogleNews.Columns["title_"].Caption = "新聞標題";
            //--來源連結 link_
            dtGoogleNews.Columns.Add("link_", typeof(string));
            dtGoogleNews.Columns["link_"].Caption = "原始連結";
            //--關鍵字權重 weight_
            dtGoogleNews.Columns.Add("weight_", typeof(decimal));
            //--大綱 desc_
            dtGoogleNews.Columns.Add("desc_", typeof(string));
            dtGoogleNews.Columns["desc_"].Caption = "大綱";
            //--情緒正負向 sentiments_
            //dtGoogleNews.Columns.Add("sentiments_", typeof(string));
            //--異動日期 upd_date_
            //dtGoogleNews.Columns.Add("upd_date_", typeof(DateTime));
            //--異動者 upd_user_
            //dtGoogleNews.Columns.Add("upd_user_", typeof(string));

            //綁定至 dataGridView1
            dataGridView1.DataSource = dsESG;
            dataGridView1.DataMember = "ns_news";
            //dataGridView1.AutoGenerateColumns = false;
            //修改 dataGridView Caption & Hidden
            DataGridViewCellStyle cellStyle = new DataGridViewCellStyle();
            cellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            cellStyle.ForeColor = Color.Blue;
            cellStyle.SelectionForeColor = Color.Black;
            cellStyle.Font = new Font(FontFamily.GenericSansSerif, 10, FontStyle.Underline);

            //dataGridView1.Columns[0].Visible = false; //search_id_
            dataGridView1.Columns[0].HeaderText = "關鍵字";
            dataGridView1.Columns[0].Resizable = DataGridViewTriState.True;
            dataGridView1.Columns[1].HeaderText = "發布時間";
            dataGridView1.Columns[1].Resizable = DataGridViewTriState.True;
            dataGridView1.Columns[2].HeaderText = "新聞來源";
            dataGridView1.Columns[2].Resizable = DataGridViewTriState.True;
            dataGridView1.Columns[3].HeaderText = "新聞標題";
            dataGridView1.Columns[3].Resizable = DataGridViewTriState.True;
            dataGridView1.Columns[4].HeaderText = "原始連結";
            dataGridView1.Columns[4].DefaultCellStyle = cellStyle;
            dataGridView1.Columns[5].HeaderText = "命中數量";
            dataGridView1.Columns[5].Resizable = DataGridViewTriState.True;
            dataGridView1.Columns[6].HeaderText = "大綱";
            dataGridView1.Columns[6].Visible = false; //desc_
            //dataGridView1.Columns[6].DataPropertyName = ColumnName.ReportsTo.ToString();
            //dataGridView1.Columns[6].Resizable = DataGridViewTriState.True;
            //dataGridView1.Columns[7].Visible = false; //sentiments_
            //dataGridView1.Columns[8].Visible = false; //weight_
            //dataGridView1.Columns[9].Visible = false; //upd_date_
            //dataGridView1.Columns[10].Visible = false; //upd_user_

        }

        //查詢google
        private void button1_Click(object sender, EventArgs e)
        {
            //url = @"http://www.taifex.com.tw/cht/5/stockMargining";
            //memoryStream = new MemoryStream(webClient.DownloadData(url));

            ////使用HtmlDocument.Load()進行編碼，使用UTF8編譯，取得整份網頁結構
            //HtmlDocument doc = new HtmlDocument();
            //doc.Load(memoryStream, Encoding.UTF8);

            //HtmlDocument docData = new HtmlDocument();
            //docData.LoadHtml(doc.DocumentNode.SelectSingleNode(@"//div[@name='printhere']").InnerHtml);

            ////獲得更新日期
            //UpdateDate = docData.DocumentNode.SelectSingleNode(@"/div/p/span").InnerText;

            ////從docData向下取得網頁上目標表格的html結構
            //HtmlDocument dt_html = new HtmlDocument();
            //dt_html.LoadHtml(docData.DocumentNode.SelectSingleNode(@"//table[@class='table_c']")
            //                                     .InnerHtml);
            ////批次取得th資料，利用這些資料進行IEnumarable創造dt的Column
            //HtmlNodeCollection headers = dt_html.DocumentNode.SelectNodes(@"//tbody/tr/th");

            //foreach (HtmlNode header in headers)
            //{
            //    dt.Columns.Add(header.InnerText);
            //    textBox2.AppendText(header.InnerText);
            //}

            ////可用rows取得所有列的資料，也可直接寫在foreach裡面，tr[td]的意思是選取「所有tr之下有td」的tr們
            ////HtmlNodeCollection rows = dt_html.DocumentNode.SelectNodes(@"//tr[td]");
            //foreach (HtmlNode row in dt_html.DocumentNode.SelectNodes(@"//tr[td]"))
            //{
            //    //再用SelectNodes批次取得所有td的資料，利用lambda語法取得所有InnerText
            //    dt.Rows.Add(row.SelectNodes(@"td").Select(td => td.InnerText.Trim()).ToArray());
            //}
            //textBox1.Text = UpdateDate;
            //dataGridView1.DataSource = new BindingSource(dt, null);
            //dataGridView1.ColumnHeadersDefaultCellStyle.WrapMode = DataGridViewTriState.False;
            //dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;


            //MessageBox.Show(textBox1.Text);
        }

        //查詢關鍵字
        private void button3_Click(object sender, EventArgs e)
        {
            string match_title_ = "", match_keyword = "", match_kword = ""; 

            //符合負面關鍵字詞數量
            int match_cnt = 0;

            //命中負面關鍵字詞筆數
            int match_Recordcount = 0;

            //讀入ESG 關鍵字詞庫
            List<String> Checklist = new List<String>();
            if (SearchWord.Text != "")
            {
                Checklist = SearchWord.Text.Split(',').ToList();

                //保留查詢回訊
                if (checkBox1.Checked == false)
                {
                    //清除TextBon資料
                    textBox2.Clear();
                    //清除資料表
                    dtGoogleNews.Rows.Clear();
                }
                //依名單查詢
                foreach (string value in Checklist)
                {
                    //搜尋: 關鍵字,查詢期間,國家
                    //Googlenews_Search(SearchWord.Text, comboBox3.SelectedIndex, comboBox2.SelectedItem.ToString(), comboBox1.Text);                
                    Googlenews_Search(value, comboBox3.SelectedIndex, comboBox2.SelectedItem.ToString(), comboBox1.Text);
                    write2text("===== 查詢結束 ===== "+ DateTime.Now.ToString()  );
                }

                //篩選有負面關鍵字的新聞
                if (checkBox2.Checked == true)
                {
                    //負面ESG關鍵字
                    List<String> KeywordList = new List<String>();
                    KeywordList = negative.Split(',').ToList();

                    //遍歷原始新聞資料集
                    int total_cnt = dtGoogleNews.Rows.Count - 1;
                    for (int i = total_cnt; i >= 0; i--)
                    {
                        match_cnt = 0;
                        //中文依介面選項轉換繁體或簡體
                        switch (comboBox1.SelectedIndex)
                        {
                            case 0:// 簡體
                                match_title_ = ConvertChinese(dtGoogleNews.Rows[i]["title_"].ToString(), CharsetType.Simplified);
                                match_keyword = ConvertChinese(dtGoogleNews.Rows[i]["search_nm_"].ToString(), CharsetType.Simplified);
                                break;
                            case 4://香港中文
                            case 2:// 繁體
                                match_title_ = ConvertChinese(dtGoogleNews.Rows[i]["title_"].ToString(), CharsetType.Traditional);
                                match_keyword = ConvertChinese(dtGoogleNews.Rows[i]["search_nm_"].ToString(), CharsetType.Traditional);
                                break;
                            default:
                                match_title_ = dtGoogleNews.Rows[i]["title_"].ToString();
                                match_keyword = dtGoogleNews.Rows[i]["search_nm_"].ToString();
                                break;
                        }

                        //if matched then saved, or remove
                        if (match_title_.IndexOf(match_keyword) != -1)
                        {
                            //MessageBox.Show(match_keyword + Environment.NewLine
                            //                                   + match_title_);
                            //比對符合多少負面關鍵字
                            foreach (string kword in KeywordList)
                            {
                                //負面關鍵字-中文依介面選項轉換繁體或簡體
                                switch (comboBox1.SelectedIndex)
                                {
                                    case 0:// 簡體
                                        match_kword = ConvertChinese(kword, CharsetType.Simplified);
                                        break;
                                    case 4:// 香港中文
                                    case 2:// 繁體
                                        match_kword = ConvertChinese(kword, CharsetType.Traditional);
                                        break;
                                    default:
                                        match_kword = match_kword;
                                        break;
                                }
                                
                                if (match_title_.IndexOf(match_kword) != -1)
                                {
                                    match_cnt = match_cnt + 1;                                    
                                }
                            }
                            // 無負面關鍵字
                            if (match_cnt == 0)
                            {
                                //MessageBox.Show("NoMatch:" + match_cnt.ToString() +":" + match_title_ );
                                //dtGoogleNews.Rows[i].Delete();                                
                            }
                            else
                            {
                                match_Recordcount = match_Recordcount + 1;
                                dtGoogleNews.Rows[i]["weight_"] = match_cnt;
                                //MessageBox.Show("Match:" + match_cnt.ToString() + ":"  + match_title_  ); 

                            }
                        }
                        else
                        {
                            //delete no match keyword record
                            dtGoogleNews.Rows[i].Delete();
                        }
                    }
                    dtGoogleNews.AcceptChanges();

                    if (dtGoogleNews.Rows.Count == 0)
                    {
                        MessageBox.Show("查無符合新聞資訊");
                    }
                    else
                    {
                        MessageBox.Show("檢視新聞共 " + dtGoogleNews.Rows.Count.ToString("#,0") + " 筆" 
                                       + Environment.NewLine
                                       + "符合負面新聞共 " + match_Recordcount.ToString("#,0") + " 筆");
                    }
                }
                else
                {
                    MessageBox.Show("查詢新聞資訊共 " + dtGoogleNews.Rows.Count.ToString("#,0") + " 筆");
                }
            }
        }

        //控制查詢url-textbox
        private void label5_DoubleClick(object sender, EventArgs e)
        {
            if (tb_url.Visible == true)
            { tb_url.Visible = false; }
            else
            { tb_url.Visible = true; }
        }

        //填入即時時間
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel4.Text = DateTime.Now.ToString();
            toolStripStatusLabel2.Text = DateTime.Now.ToString();
        }

        //Export Excel
        private void button2_Click(object sender, EventArgs e)
        {
            string vTime;
            vTime = DateTime.Now.Year.ToString("0000") + DateTime.Now.Month.ToString("00") + DateTime.Now.Day.ToString("00");
            ExportExcel(vTime + "_ESG新聞_"+ SearchWord.Text.Substring(0,4), dataGridView1);
        }

        //Test filter 負面字樣
        private void button4_Click(object sender, EventArgs e)
        {
            string match_searchword = "", match_lines = "", match_keyw = "";
            //查詢關鍵字
            List<String> searchList = new List<String>();
            searchList = SearchWord.Text.Split(',').ToList();

            //負面ESG關鍵字
            List<String> KeywordList = new List<String>();
            KeywordList = textBox1.Text.Split(',').ToList();

            //關鍵字
            foreach (string searchword in searchList)
            {
                
                //MessageBox.Show(ConvertChinese(searchword, CharsetType.Default) + Environment.NewLine +
                //                ConvertChinese(searchword, CharsetType.Simplified) + Environment.NewLine +
                //                ConvertChinese(searchword, CharsetType.Traditional) + Environment.NewLine
                //               );
                match_searchword = ConvertChinese(searchword, CharsetType.Traditional);
                //新聞條文清單
                foreach (string lines in textBox3.Lines)
                {
                    //檢查新聞標題中是否包含關鍵字,若有才進入負面關鍵字檢查
                    match_lines = ConvertChinese(lines, CharsetType.Traditional);
                    if (match_lines.IndexOf(searchword) != -1)
                    {
                        //檢查負面關鍵字
                        foreach (string keyw in KeywordList)
                        {
                            match_keyw = ConvertChinese(keyw, CharsetType.Traditional);
                            if (match_lines.IndexOf(keyw) != -1)
                            {
                                MessageBox.Show(lines);
                            }
                        }
                    }
                }
            }

   
            //所有新聞
            //foreach (string value in Checklist)
            //{

            //}
        }

        //執行hyperlinks
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string cellstr = "";
            if (e.RowIndex == -1) return; //按到headertext 無效

            if (e.ColumnIndex == 4)
            {
                cellstr = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                //MessageBox.Show(cellstr);
                //use browser 
                string url = string.Format(cellstr);
                System.Diagnostics.Process.Start(url);
            }
        }
    }
}
