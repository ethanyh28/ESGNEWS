﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExtensionMethods;
using System.IO;

namespace update
{
    public partial class F_update : Form
    {

        //read ini
        string dirstr = Application.StartupPath + "\\EsgNewsSearch_utf8.ini";


        //寫入TextBox
        private void write2text(string str)
        {
            textBox1.AppendText(str + System.Environment.NewLine);
        }

        public F_update()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void F_update_Shown(object sender, EventArgs e)
        {
            /*
              * 取得版本資訊
              * 進行版本比對
              * 強制關閉正在運作的ESGNEWSSEARCH
              * 刪除舊檔
              * 複製新檔
              * 更新完成
              * 關閉升級程式
              * 最後更新update.exe使用檔案最後異動日期
              */
            //get local release version info
            string release_version = ExtensionMethods.MyExtensions.ReadString("VERSION_CONTROL", "RELEASE_VERSION", "", dirstr);
            //get server path
            string SERVER_PATH = ExtensionMethods.MyExtensions.ReadString("VERSION_CONTROL", "SERVER", "", dirstr);
            //取得server new version info
            string new_version = ExtensionMethods.MyExtensions.ReadString("VERSION_CONTROL", "NEW_VERSION", "", SERVER_PATH + "\\VERSION.INI");
            //取得main program name
            string program_nm = ExtensionMethods.MyExtensions.ReadString("VERSION_CONTROL", "PROGRAM_NM", "", SERVER_PATH + "\\VERSION.INI");

            try
            {
                //MessageBox.Show(SERVER_PATH + "\\VERSION.INI");
                //檢查新版本                  
                textBox1.Clear();
                DirectoryInfo theFolder = new DirectoryInfo(SERVER_PATH);
                if (theFolder.Exists)
                {
                    write2text("主機位置:" + SERVER_PATH + "\\VERSION.INI");
                    write2text("目前本機版本:" + release_version);
                    write2text("目前主機版本:" + new_version);
                    if (new_version.CompareTo(release_version) > 0)
                    {

                        write2text("發現新版本");
                        write2text("即將升級程式");
                        write2text("關閉 " + program_nm);
                        System.Diagnostics.Process[] proc = System.Diagnostics.Process.GetProcessesByName(program_nm);
                        foreach (System.Diagnostics.Process pro in proc)
                        {
                            pro.Kill();
                        }

                        //讀取server path all file exclude version.ini
                        foreach (FileInfo theFile in theFolder.GetFiles())
                        {
                            if ((Path.GetFileName(theFile.FullName) != "VERSION.INI") && (Path.GetFileName(theFile.FullName) != "EsgUpdate.exe" ))
                            {
                                //如果臨時文件夾下存在與應用程式所在目錄下的文件同名的文件，則刪除應用程式目錄下的文件
                                if (File.Exists(Application.StartupPath + "\\" + Path.GetFileName(theFile.FullName)))
                                {
                                    write2text("刪除舊檔案" + Path.GetFileName(theFile.FullName));
                                    File.Delete(Application.StartupPath + "\\" + Path.GetFileName(theFile.FullName));
                                }
                                //delete local path , the same delete file
                                write2text("複製新檔案" + Path.GetFileName(theFile.FullName));
                                File.Copy(theFile.FullName, Application.StartupPath + "\\" + Path.GetFileName(theFile.FullName));
                            }
                        }
                        write2text("更新完成");
                        write2text("重新啟動 " + program_nm);

                        timer1.Interval = 2000;
                        timer1.Enabled = true;
                        
                        timer1.Tick += delegate {
                            SendKeys.Send("{ENTER}");
                            timer1.Enabled = false;
                            System.Diagnostics.Process.Start(Application.StartupPath + "\\" + program_nm + ".exe");
                        };

                    }
                    else if (new_version.CompareTo(release_version) == 0)
                    {
                        write2text("目前軟體已經是最新的，無需更新！");
                        timer1.Interval = 250;
                        timer1.Enabled = true;
                        timer1.Tick += delegate {
                            SendKeys.Send("{ENTER}");
                            timer1.Enabled = false;
                            System.Diagnostics.Process.Start(Application.StartupPath + "\\" + program_nm + ".exe");
                        };
                    }
                    else if (new_version.CompareTo(release_version) < 0)
                    {
                        write2text("您的本機程式比主機端版本還新!!");
                        write2text("請連絡系統人員!");
                    }
                }
                else
                {
                    write2text("找不到更新資料!!");
                    write2text("請連絡系統人員!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //update update.exe use the last date
                //write2text("升級程式版本檢查");
                //write2text("更新升級程式");
                /*
                 *      timer1.Interval = 3000;
                        timer1.Enabled = true;
                        batstring = SERVER_PATH + @"\update.bat 'hello' ";
                        timer1.Tick += delegate { 
                                          SendKeys.Send("{ENTER}");
                                          Process.Start(batstring);
                        };
                        MessageBox.Show("發現新版本即將更新,即將關閉此程式!!", "版本更新通知");
                        timer1.Enabled = false;
                */
                write2text("結束升級程式");
            }
        }
    }
}
